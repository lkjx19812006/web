 var _hmt = _hmt || [];
 var fn = function() {
     let str = 'script';
     var hm = document.createElement(str);
     hm.src = 'https://hm.baidu.com/hm.js?2ade029fb49e8b3ff8fcac30343d32a4';
     var s = document.getElementsByTagName(str)[0];
     s.parentNode.insertBefore(hm, s);
 }
 fn();
