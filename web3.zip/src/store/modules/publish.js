import httpService from '../../common/httpService'


const state = {
    locationSpec: {
        default: null,
        specList: [],
        localList: []
    },
    unitIdList: [],
    editItemInfo: {}
}

// getters
const getters = {

}

// actions
const actions = {

}

// mutations
const mutations = {

}

export default {
    state,
    getters,
    actions,
    mutations
}
