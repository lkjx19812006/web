<style lang="less" scoped>
	
</style>
<template>
	<div class="newVerInfo">
				
	</div>
</template>
<script>
	export default {
		data(){
			return {

			}
		}
	}
</script>